# Flappy Bird Game

A simple Flappy Bird clone built with React, Canvas, and TailwindCSS. Click anywhere to flap.